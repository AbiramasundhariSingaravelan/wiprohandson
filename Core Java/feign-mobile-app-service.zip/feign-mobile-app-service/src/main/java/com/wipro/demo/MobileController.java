package com.wipro.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MobileController {

	@GetMapping("/mobiles")
	public Mobile getMobile()
	{
		return new Mobile(1,"Redmi",50000);
	}
}
