package com.wipro.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeignMobileAppServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeignMobileAppServiceApplication.class, args);
	}

}
