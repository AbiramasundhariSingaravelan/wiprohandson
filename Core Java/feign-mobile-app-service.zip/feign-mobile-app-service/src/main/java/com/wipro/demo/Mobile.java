package com.wipro.demo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Mobile {

	private int id;
	private String brand;
	private int price;
}
