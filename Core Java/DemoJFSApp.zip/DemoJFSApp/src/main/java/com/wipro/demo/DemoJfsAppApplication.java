package com.wipro.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJfsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoJfsAppApplication.class, args);
	}

}
