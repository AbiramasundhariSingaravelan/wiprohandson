import java.util.Scanner;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		//System.out.println("Initial Value: "+a);
		System.out.println("Post Increment: "+(a++));//10//Post Increment-10
		System.out.println("Post Increment: "+(a++));//11Pre Increment
		System.out.println("Post Increment2: "+(a++));//12Pre Increment
		System.out.println("Final Value: "+a);
	}

}