
class Welcome
{
	public void greet()
	{
		System.out.println("Greetings.....");
	}
	public void hello()
	{
		System.out.println("Greetings.....");
	}
}

public class ClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ClassName objName=new ClassName()
		Welcome w=new Welcome();
		w.greet();
		w.hello();
	}

}
