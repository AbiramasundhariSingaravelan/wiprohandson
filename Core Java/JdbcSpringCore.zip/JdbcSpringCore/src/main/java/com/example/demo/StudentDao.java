package com.example.demo;

import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDao {

	JdbcTemplate jdbc;
	public void setJdbcTemplate (JdbcTemplate temp)
	{
			this.jdbc=jdbc;
	}
	public int save(Student s)
	{
		String query="insert into student values("+s.getId()+"','"
	+s.getName()+"','"+	s.getDept()+"')";
				return jdbc.update(query);
	}
	public int updateStudent(Student s)
	{
		String query="update student set name ='"+s.getName()+"',Dept='"+s.getDept()+"' where id='"+s.getId()+"'";
		return jdbc.update(query);
	}
	public int deleteStudent(Student s)
	{
		String query="delete from student where id='"+s.getId()+"'";
		return jdbc.update(query);
	}
}
