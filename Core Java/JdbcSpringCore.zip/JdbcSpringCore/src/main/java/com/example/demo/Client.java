package com.example.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		StudentDao dao=(StudentDao)ctx.getBean("sdao");
		int status=dao.save(new Student(100,"Arthi","CSE"));
		System.out.println(status);
		
	
	}

}
