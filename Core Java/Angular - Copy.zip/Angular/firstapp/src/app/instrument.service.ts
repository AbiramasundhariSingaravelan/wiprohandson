import { Injectable } from '@angular/core';
import { Instrument } from './instrument';

@Injectable({
  providedIn: 'root'
})
export class InstrumentService {

  public getInstruments()
  {
    let instruments:Instrument[];
    instruments=[
      new Instrument(1,'Veena','String',50000),
      new Instrument(2,'Guitar','String',80000),
      new Instrument(3,'Violin','String',40000),
      new Instrument(4,'Flute','Wind',450000),
      new Instrument(5,'Trumphet','Wind',60000)
    ]
    return instruments;
  }
  constructor() { }
}
