import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CoursesComponent } from './courses/courses.component';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { StudentComponent } from './student/student.component';
import { ContactComponent } from './contact/contact.component';
import { InstrmentsComponent } from './instrments/instrments.component';

const routes: Routes = [
  //{path:'home',component:AppComponent},
  {path:'courses-menu',component:CoursesComponent},
  {path:'view-product', component:ProductComponent},
  {path:'view-product-details',component:ProductDetailsComponent},
  {path:'view-student',component:StudentComponent},
  {path:'view-contact', component:ContactComponent},
  {path:'view-instruments',component:InstrmentsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
