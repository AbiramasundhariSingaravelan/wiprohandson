import { Component, OnInit } from '@angular/core';
import { course_list } from '../lcourse';
import { Course } from '../course';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  constructor() { }
c=course_list;
selected_course?:Course;
  ngOnInit(): void {
  }
  onClick(scourse:Course)
  {
    this.selected_course=scourse;
  }
}
