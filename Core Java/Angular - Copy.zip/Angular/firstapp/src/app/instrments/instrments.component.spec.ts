import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstrmentsComponent } from './instrments.component';

describe('InstrmentsComponent', () => {
  let component: InstrmentsComponent;
  let fixture: ComponentFixture<InstrmentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstrmentsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InstrmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
