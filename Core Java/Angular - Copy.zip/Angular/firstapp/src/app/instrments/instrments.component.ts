import { Component, OnInit } from '@angular/core';
import { Instrument } from '../instrument';
import { InstrumentService } from '../instrument.service';

@Component({
  selector: 'app-instrments',
  templateUrl: './instrments.component.html',
  styleUrls: ['./instrments.component.css']
})
export class InstrmentsComponent implements OnInit {

  ins?:Instrument[];
  insService:any;
  constructor() {
    this.insService=new InstrumentService();
   }
   getInstruments()
   {
    this.ins=this.insService.getInstruments();
   }

  ngOnInit(): void {
  }

}
