import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: 
  ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  firstName =new FormControl(1,Validators.required);
  lastName=new FormControl("",Validators.maxLength(2));
  addr=new FormControl("",Validators.required);
  
  constructor() { }

  ngOnInit(): void {
  }

}
