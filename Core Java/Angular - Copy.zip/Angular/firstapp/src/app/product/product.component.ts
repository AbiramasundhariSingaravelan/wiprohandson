import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  enableClass="tblName"
  styling=[{
    color:"red",
    border:"1px solid red"
  }]
products:any[]=[{
  "pid":1,
  "pname":"Product1",
  "price":100,
  "rating":4.5
},
{
  "pid":2,
  "pname":"Product2",
  "price":200,
  "rating":4
},
{
  "pid":3,
  "pname":"Product3",
  "price":300,
  "rating":5
},
{
  "pid":4,
  "pname":"Product4",
  "price":400,
  "rating":3.5
},
{
  "pid":5,
  "pname":"Product5",
  "price":500,
  "rating":4
},
]
msgfromChild=''
getValues(message:string)
{
this.msgfromChild='Product Details Report'+message
}
}
