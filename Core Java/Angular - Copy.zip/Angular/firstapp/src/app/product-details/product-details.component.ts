import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  ngOnChanges()
  {
    if(this.rating==4)
    {
      this.rating_value='Good';
    }
    else if(this.rating==3.5)
    {
      this.rating_value='OK';
    }
    else if(this.rating==3)
    {
      this.rating_value='Need to Improve'
    }
    else if(this.rating==5)
    {
      this.rating_value='Excellent';
    }
    else
    {
      this.rating_value='Undefined';
    }
  }
  @Input() rating:number=5;//value is coming from parent component
rating_value:string="Default";//value is coming from parent component
@Output() GetRating:EventEmitter<string>=new EventEmitter<string>();
onClick():void
{
  this.GetRating.emit('Event Triggered rating is $(this.rating_value)')
}
}
