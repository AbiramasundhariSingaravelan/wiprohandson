import { Directive, ElementRef, HostListener, Input } from "@angular/core";

@Directive({
    selector:'[myHighlight]'
})
export class HighlighterDirective
{
    constructor(private e1:ElementRef)
    {

    }
   @Input() defaultColor?:string;
   @Input('myHighlight') highlightColor?:string;
   private highlight(color:string)
   {
    this.e1.nativeElement.style.backgroundColor=color;
   }
   @HostListener('mouseenter')
   onMouseEnter()
   {
    this.highlight(this.highlightColor || this.defaultColor || 'red');
   }
   @HostListener('mouseleave')
   onMouseLeave()
   {

    this.highlight("");
   }
}