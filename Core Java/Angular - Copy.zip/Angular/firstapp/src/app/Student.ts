export class Student{
    id:number;
    sname:string;
    dept:string;
    addr:string
    constructor(id:number,sname:string,dept:string,addr:string)
    {
        this.id=id;
        this.sname=sname;
        this.dept=dept;
        this.addr=addr;
    }
}