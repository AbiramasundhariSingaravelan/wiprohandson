import { Course } from "./course";
export const course_list:Course[]=[
    {id:1,name:"Angular",price:5000,duration:90},
    {id:2,name:"DotNet",price:6000,duration:90},
    {id:3,name:"Java",price:7000,duration:90},
    {id:4,name:"React",price:8000,duration:90},
    {id:5,name:"PHP",price:9000,duration:90},
    
]