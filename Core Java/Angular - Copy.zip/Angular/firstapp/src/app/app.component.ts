import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl:'app.component.html',
  template: `<div>
  <input type="radio" name="colors" (click)="Color='green'"/>green
  <input type="radio" name="colors" (click)="Color='pink'"/>Pink
  <input type="radio" name="colors" (click)="Color='blue'"/>Red
  Highlight Me!
  
</div>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  className="myTextBox";
  username ="Arthi";
  txtValue="Angular"
  Color="red";
  triggerClick()
  {
    alert('Event Triggered');
  }
}
