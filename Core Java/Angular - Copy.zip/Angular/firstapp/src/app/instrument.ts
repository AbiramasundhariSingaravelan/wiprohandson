export class Instrument
{
    insId:number;
    insName:string;
    insType:string;
    price:number;
    constructor(insId:number,insName:string,insType:string,price:number)
    {
        this.insId=insId;
        this.insName=insName;
        this.insType=insType;
        this.price=price;
    }
}