package com.example.demo;

public class B {

	B()
	{
		System.out.println("B is created");
	}
	void print()
	{
		System.out.println("Inside B Class");
	}
}
