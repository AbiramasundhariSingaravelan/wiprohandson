package com.wipro.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.demo.model.Course;

public interface CourseRepository extends JpaRepository<Course,Integer>
{

}
