package com.wipro.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="course_table")
public class Course {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cid;
	@Column
	private String name;
	@Column
	private int duration;
	@Column
	private int price;
	@Column
	private String trainer;
	@Column
	private int stReg;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getTrainer() {
		return trainer;
	}
	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}
	public int getStReg() {
		return stReg;
	}
	public void setStReg(int stReg) {
		this.stReg = stReg;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Course(int cid, String name, int duration, int price, String trainer, int stReg) {
		super();
		this.cid = cid;
		this.name = name;
		this.duration = duration;
		this.price = price;
		this.trainer = trainer;
		this.stReg = stReg;
	}
	
}
