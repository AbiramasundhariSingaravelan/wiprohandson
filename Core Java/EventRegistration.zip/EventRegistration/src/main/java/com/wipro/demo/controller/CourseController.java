package com.wipro.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wipro.demo.model.Course;
import com.wipro.demo.repository.CourseRepository;

@Controller
public class CourseController {

	@Autowired
	CourseRepository courseRepo;
	@RequestMapping("/register")
	public String courseRegister()
	{
		return "addCourse";
	}
	@RequestMapping("/addcourse")
	@ResponseBody
	public String addCourse(@ModelAttribute Course c)
	{
		courseRepo.save(c); // add the data into the database
		return "Course Added to Database";
	}
	@RequestMapping("/viewcourse")
	@ResponseBody
	public List<Course> getAllCourses()
	{
		return courseRepo.findAll();
	}
	@RequestMapping("/viewcourse/{cid}")
	@ResponseBody
	public Optional<Course> getCoursesById(@PathVariable int cid)
	{
		return courseRepo.findById(cid);
	}
	@RequestMapping("/deletecourse/{cid}")
	@ResponseBody
	public String deleteCoursesById(@PathVariable int cid)
	{
		 courseRepo.deleteById(cid);
		 return "Course Deleted";
	}
	@RequestMapping("/updatecourse/{cid}")
	@ResponseBody
	public Course updateCourse(@ModelAttribute Course c, @PathVariable int cid)
	{
		return courseRepo.save(c);
	}
}
