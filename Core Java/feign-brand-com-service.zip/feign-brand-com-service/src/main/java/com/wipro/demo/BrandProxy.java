package com.wipro.demo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("http://localhost:9095/mobiles")
public interface BrandProxy {

	@GetMapping("/feign/mobile/name")
	Mobile getBrand();
}
