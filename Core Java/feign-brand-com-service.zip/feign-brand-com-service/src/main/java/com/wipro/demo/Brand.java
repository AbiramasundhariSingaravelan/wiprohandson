package com.wipro.demo;

public class Brand {

	Mobile brand;

	public Mobile getBrand() {
		return brand;
	}

	public void setBrand(Mobile brand) {
		this.brand = brand;
	}

	public Brand() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Brand(Mobile brand) {
		super();
		this.brand = brand;
	}
	
}
