package com.wipro.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BrandController {

	@Autowired
	BrandProxy bp;
	public Mobile getBrand()
	{
		Mobile m=bp.getBrand();
		return m;
	}
}
