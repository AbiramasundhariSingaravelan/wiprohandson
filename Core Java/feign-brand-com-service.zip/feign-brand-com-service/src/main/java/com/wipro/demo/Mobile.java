package com.wipro.demo;


public class Mobile {

	private int id;
	private String brand;
	private int price;
}
