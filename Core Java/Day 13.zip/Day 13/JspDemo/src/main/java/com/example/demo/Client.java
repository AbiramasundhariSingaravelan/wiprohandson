package com.example.demo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student s=new Student();
		s.setId(100);
		s.setName("Arthi");
		System.out.println(s.getId()+" " +s.getName());
	}

}
