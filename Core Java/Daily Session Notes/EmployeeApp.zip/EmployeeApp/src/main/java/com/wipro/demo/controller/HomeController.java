package com.wipro.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wipro.demo.model.Employee;

@Controller
public class HomeController {

	@RequestMapping("/hello")
	public String greet(@RequestParam("username") String username, @RequestParam("password") String password, Model m)
	{
		if((username.equals("admin"))&&(password.equals("admin")))
		{
			String message="Login Successfull!, Welcome "+username;
			m.addAttribute("greet",message);
			return "index";
		}
		else
		{
			String message="Sorry "+username+" Invalid Credentials";
			m.addAttribute("greet",message);
			return "error";
		}
	}
	@RequestMapping("/add")
	public String addEmployee(@ModelAttribute("employee") Employee e,Model m)
	{
		m.addAttribute("employee",e);
		return "data";
	}
	@RequestMapping("/login")
	public String login()
	{
		return "login";
	}
}
