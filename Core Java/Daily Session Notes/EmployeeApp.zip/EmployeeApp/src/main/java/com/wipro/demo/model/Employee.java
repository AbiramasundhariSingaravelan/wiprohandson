package com.wipro.demo.model;

import org.springframework.stereotype.Component;

@Component
public class Employee {

	private int eno;
	private String name;
	private String dept;
	private String addr;
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int eno, String name,String dept,String addr) {
		super();
		this.eno = eno;
		this.name = name;
		this.addr=addr;
		this.dept=dept;
	}
	
}
