import java.util.Scanner;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,res,i=10;
		System.out.println("Enter the multiplication table to be printed");
		Scanner s=new Scanner(System.in);
		n=s.nextInt();
		//i++=>i=i+1;
		/*for(i=1;i<=10;i++)
		{
			res = i * n;
			System.out.println(i + " X " +n + " = "+res);
		}*/
		/*while(i<=10) {
			res = i * n;
			System.out.println(i + " X " +n + " = "+res);
			i++;
		}*/
		do
		{
			res = i * n;
			System.out.println(i + " X " +n + " = "+res);
			i++;
		}while(i<10);
	}

}