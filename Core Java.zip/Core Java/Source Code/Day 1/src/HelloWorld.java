
public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=50;
		float b=5.6453f;
		double c=567.8343;
		String d="Demo";
		char ch='A';
		System.out.println("Value of Variable: "+a);
		System.out.println("Value of Variable B: "+b);
		System.out.println("Value of Variable C: "+c);
		System.out.println("Value of Variable D: "+d);
		System.out.println("Value of Variable CH: "+ch);
		System.out.println("Hello World");
	}

}
